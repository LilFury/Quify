-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2023 at 07:19 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quify`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `aid` int(50) NOT NULL,
  `answer` text NOT NULL,
  `qid` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`aid`, `answer`, `qid`) VALUES
(33, ' Advanced Program Integration', 14),
(34, 'Application Programming Interface', 14),
(35, 'Automated Program Interaction', 14),
(36, 'Algorithmic Protocol Invocation', 14),
(37, 'To pause the execution of the loop temporarily', 15),
(38, 'To terminate the entire program', 15),
(39, 'To skip the current iteration of the loop and move to the next one', 15),
(40, ' To reset the loop counter to its initial value', 15),
(41, 'Synthesizing proteins', 16),
(42, 'Storing genetic information', 16),
(43, 'Producing energy', 16),
(44, 'Facilitating cell division', 16),
(45, '6', 17),
(46, '4', 17),
(47, '3', 17),
(48, '7', 17),
(49, 'Queue ', 18),
(50, 'Stack', 18),
(51, 'Linked List', 18),
(52, 'Tree', 18),
(53, 'Dynamic Network Service', 19),
(54, 'Domain Name System', 19),
(55, 'Data Network Security', 19),
(56, 'Digital Network Server', 19),
(57, ' HyperText Markup Language', 20),
(58, 'High-Level Text Management Language', 20),
(59, 'Hyper Transfer Markup Language', 20),
(60, 'Home Tool Markup Language', 20),
(61, 'Bubble Sort', 21),
(62, 'Insertion Sort', 21),
(63, 'Quick Sort', 21),
(64, 'Selection Sort', 21),
(65, 'To declare a new variable', 22),
(66, 'To refer to the current instance of class', 22),
(67, 'To create a static method', 22),
(68, 'To access a global variable', 22);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `qid` int(5) NOT NULL,
  `question` text NOT NULL,
  `canswer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`qid`, `question`, `canswer`) VALUES
(14, 'What does the acronym \"API\" stand for in the context of programming?', 'Application Programming Interface'),
(15, 'What is the purpose of the \"break\" statement in a loop?', 'To skip the current iteration of the loop and move to the next one'),
(16, 'What is the primary function of mitochondria in a cell?', ' Producing energy'),
(17, 'What is the x in the equation 3x - 7 = 11?', '6'),
(18, 'Which data structure follows the Last In, First Out (LIFO) principle?', 'Stack'),
(19, 'In networking, what does DNS stand for?', 'Domain Name System'),
(20, ' What does HTML stand for in web development?', 'HyperText Markup Language'),
(21, ' Which sorting algorithm has an average time complexity of O(n log n)?', 'Quick Sort'),
(22, 'What is the purpose of the \"this\" keyword in object-oriented programming?', 'To refer to the current instance of class');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
(1, 'KU MUHAMMAD FIRDAUS', 'kufirdaus001@gmail.com', 'English Year 6 SK', 'sadcsac', '2023-11-15 17:17:13');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `type` enum('admin','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `username`, `password`, `type`) VALUES
(11, 'kufirdaus001@gmail.com', 'Firdaus', '$2y$10$38Y9bU65wlFr6LJG5IXDLurMeIPmINeQ4Iy0W6euDZpw2uUzLkjG2', 'user'),
(12, 'kufirdaus002@gmail.com', 'Haruka', '$2y$10$G.f5BQntYuwy57qETacydeaggDHWtEprZcxCmpqfE9eQ5Bl9bidm.', 'admin'),
(13, 'meyyyy@gmail.com', 'meyy', '$2y$10$GknATsT91PtJ6wJy6oEOYurmdsKyV/0hjfirb341MGX4MHs1tr.V2', 'admin'),
(14, 'mey21@gmail.com', 'meymey', '$2y$10$bnO5t6hVhpDLGak97elp6uHIpzsTGJq1WRxM8QV.IT66G.sImaegq', 'user'),
(15, 'haikel@gmail.com', 'hekel', '$2y$10$ZebTBof3xVWVSKyIr5nl0.as3CsZlKAY8oZubLRIixCFS48mgx/s.', 'admin'),
(16, 'adidas@gmail.com', 'abidas', '$2y$10$HURMuJ7DKW.3buFBH0Xm1ONc99aMC6tkjW3ScK5JyDWmLNY0zylna', 'user'),
(17, 'ed@gmail.com', 'ed', '$2y$10$epJ7BICf1gFDGO/vazTZa.ktyzJUnr7lKK2XtcZjidVAedm2/2WUW', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`aid`),
  ADD KEY `test` (`qid`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`qid`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `aid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `qid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `test` FOREIGN KEY (`qid`) REFERENCES `questions` (`qid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
