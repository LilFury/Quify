<?php
// Establish a database connection (replace these with your actual database credentials)
$host = 'localhost';
$dbname = 'quify';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $type = $_POST['type'];

    // Insert user into the database
    $stmt = $pdo->prepare("INSERT INTO user (email, username, password, type) VALUES (?, ?, ?, ?)");
    $stmt->execute([$email, $username, $password, $type]);

    // Get the last inserted ID
    $lastInsertId = $pdo->lastInsertId();

    // Redirect based on user type
    if ($type === 'user') {
        header("Location: userpage.php?id=$lastInsertId");
    } elseif ($type === 'admin') {
        header("Location: adminpage.php?id=$lastInsertId");
    } else {
        // Handle other types or errors
        echo "Invalid user type";
    }

    exit();
}
?>
