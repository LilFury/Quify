<?php
// edit.php

// Establish a database connection (replace these with your actual database credentials)
$host = 'localhost';
$dbname = 'quify';
$db_username = 'root';
$db_password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $db_username, $db_password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// Check if the form is submitted for updating the question
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qid = $_POST['qid'];
    $newQuestion = $_POST['newQuestion'];
    $newCAnswer = $_POST['newCAnswer'];

    // Update the question and correct answer in the database
    $stmtUpdateQuestion = $pdo->prepare("UPDATE questions SET question = ?, canswer = ? WHERE qid = ?");
    $stmtUpdateQuestion->execute([$newQuestion, $newCAnswer, $qid]);

    // Delete existing options for the question
    $stmtDeleteOptions = $pdo->prepare("DELETE FROM answers WHERE qid = ?");
    $stmtDeleteOptions->execute([$qid]);

    // Insert updated options into the answers table
    foreach ($_POST['options'] as $option) {
        $stmtInsertOption = $pdo->prepare("INSERT INTO answers (answer, qid) VALUES (?, ?)");
        $stmtInsertOption->execute([$option, $qid]);
    }

    // Redirect to admin page after updating
    header("Location: adminpage.php");
    exit();
}

// Retrieve the question details based on the provided question ID
if (isset($_GET['qid'])) {
    $qid = $_GET['qid'];

    // Fetch question details
    $stmtGetQuestion = $pdo->prepare("SELECT * FROM questions WHERE qid = ?");
    $stmtGetQuestion->execute([$qid]);
    $question = $stmtGetQuestion->fetch(PDO::FETCH_ASSOC);

    // Fetch options for the current question
    $stmtGetOptions = $pdo->prepare("SELECT * FROM answers WHERE qid = ?");
    $stmtGetOptions->execute([$qid]);
    $options = $stmtGetOptions->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Redirect to admin page if no question ID is provided
    header("Location: adminpage.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Question</title>

<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 20px;
        }

        h2 {
            color: #333;
        }

        form {
            max-width: 500px;
            margin: 20px 0;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        a {
            display: block;
            margin-top: 20px;
            color: #3498db;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
    </head>
<body>
<h2>Edit Question</h2>
    <form action="edit.php" method="post">
        <input type="hidden" name="qid" value="<?= $question['qid']; ?>">
        
        <label for="newQuestion">New Question:</label>
        <input type="text" name="newQuestion" value="<?= $question['question']; ?>" required><br>

        <label for="newCAnswer">New Correct Answer:</label>
        <input type="text" name="newCAnswer" value="<?= $question['canswer']; ?>" required><br>

        <label for="options">Options:</label>
        <?php foreach ($options as $option): ?>
            <input type="text" name="options[]" value="<?= $option['answer']; ?>" required><br>
        <?php endforeach; ?>

        <input type="submit" value="Update Question">
    </form>

    <a href="adminpage.php">Back to Admin Page</a>
</body>
</html>
