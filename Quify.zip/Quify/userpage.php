<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('QuifyBackground.jpg');
            /* Set the path to your background image */
            background-position: center;
        }

        html,
        body {
            height: 100%;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.8);
            /* Background color for the container */
            padding: 20px;
            width: 50%;
            margin: 0 auto;
            height: 40%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        h1 {
            margin: 0;
        }

        .content {
            padding: 20px;
            text-align: center;
        }

        h3 {
            color: #333;
            margin-top: 20px;
        }

        p {
            color: #333;
        }

        .start-button {
            display: inline-block;
            padding: 10px 15px;
            background-color: #3498db;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .start-button:hover {
            background-color: #2980b9;
        }

        header ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logout-button {
            display: inline-block;
            padding: 8px 12px;
            background-color: #e74c3c;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            margin-right: auto;
        }

        .logout-button:hover {
            background-color: #c0392b;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }
    </style>
</head>

<body>
    <header>
        <ul>
            <li><a href="userpage.php"><img src="quifylogos.png" width="80" height="40"></a></li>
            <li><a href="team.php">Team Gallery</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li class="logout-container">
                <a href="login.php" class="logout-button">Logout</a>
            </li>
        </ul>
    </header>



    <div class="container">
        <div class="content">
            <h3>WELCOME TO QUIFY !!</h3>
            <p>Click the button below to start answering questions.</p>

            <a href="quiz.php" class="start-button">Start the Quiz</a>
        </div>
        <iframe width="420" height="315" src="https://www.youtube.com/embed/LkdKwHVhSO4&ab">
        </iframe>
    </div>
</body>

</html>