<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Team Gallery</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('QuifyBackground.jpg');
            background-position: center;
        }

        .container {
            background-color: lightgrey;
            padding: 20px;
            width: 80%;
            margin: 20px auto;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        h1 {
            margin: 0;
        }

        .team-member {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 20px 0;
        }

        .team-member img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin-bottom: 10px;
        }

        .position {
            font-style: italic;
            color: #777;
        }

        header ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logout-button {
            display: inline-block;
            padding: 8px 12px;
            background-color: #e74c3c;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            margin-right: auto;
        }

        .logout-button:hover {
            background-color: #c0392b;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }
    </style>
</head>
<body>
<header>
        <ul>
            <li><a href="userpage.php"><img src="quifylogos.png" width="80" height="50"></a></li>
            <li><a href="team.php">Team Gallery</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li class="logout-container">
                <a href="login.php" class="logout-button">Logout</a>
            </li>
        </ul>
    </header>

    <div class="container">
        <div class="team-member">
            <img src="amirul.jpg" alt="CEO">
            <h3>Muhammad Amirul Hadi</h3>
            <p class="position">CEO</p>
            <p>Introduction: The one who shares the company ideas to the whole team. Leads the team, divide tasks and discuss plan in details to success.</p>
        </div>

        <div class="team-member">
            <img src="firdaus.jpg" alt="Co-CEO">
            <h3>Ku Muhammad Firdaus</h3>
            <p class="position">Co-CEO</p>
            <p>Introduction: The one who codes multiple of database and pages until success to make the website working smoothly without fail..</p>
        </div>

        <div class="team-member">
            <img src="dahnial.jpg" alt="Designer">
            <h3>Muhamad Dahnial</h3>
            <p class="position">Designer</p>
            <p>Introduction: The one who codes multiple of styles to beautify the website pages and runs login/signup page until it works smoothly without any error.</p>
        </div>

    </div>
</body>
</html>
