<!-- result.php -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('QuifyBackground.jpg');
            background-position: center;
        }

        html,
        body {
            height: 100%;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        h1 {
            margin: 0;
        }

        .result-container {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            width: 50%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin-top: 50px;
        }

        h2,
        h3 {
            color: #333;
            margin-top: 20px;
        }

        .question-result {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .correct {
            color: #27ae60;
        }

        .incorrect {
            color: #e74c3c;
        }

        header ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logout-button {
            display: inline-block;
            padding: 8px 12px;
            background-color: #e74c3c;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            margin-right: auto;
        }

        .logout-button:hover {
            background-color: #c0392b;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }
    </style>
</head>

<body>
    <header>
    <ul>
            <li><a href="userpage.php"><img src="quifylogos.png" width="80" height="50"></a></li>
            <li><a href="team.php">Team Gallery</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li class="logout-container">
                <a href="login.php" class="logout-button">Logout</a>
            </li>
        </ul>
    </header>


    <div class="result-container">
        <h2>Your Quiz Results</h2>

        <?php
        // Retrieve userAnswers and questions from the URL
        $userAnswers = json_decode($_GET['userAnswers'], true);
        $questions = isset($_GET['questions']) ? json_decode(urldecode($_GET['questions']), true) : [];

      // ...

// Count the number of correct answers
$correctCount = 0;

// Compare user's answers with correct answers and display results
foreach ($questions as $index => $q) {
    echo '<div class="question-result">';
    echo '<label><strong>Question:</strong> ' . $q['question'] . '</label>';
    echo '<p>Your Answer: ' . $userAnswers[$index] . '</p>';

    // Retrieve the correct answer from the 'canswer' column
    $correctAnswer = $q['canswer'];

    // Check if user's answer is correct
    $isCorrect = ($userAnswers[$index] === $correctAnswer);

    if ($isCorrect) {
        $correctCount++;
        echo '<p class="correct">Correct!</p>';
    } else {
        echo '<p class="incorrect">Incorrect!</p>';
        echo '<p>Correct Answer: ' . $correctAnswer . '</p>';
    }

    echo '</div>';
}

// Calculate and display the score and percentage
$totalQuestions = count($questions);
$percentage = round(($correctCount / $totalQuestions) * 100);

echo '<div>';
echo '<p>Your Score: ' . $correctCount . '/' . $totalQuestions . '</p>';
echo '<p>Percentage: ' . $percentage . '%</p>';
echo '</div>';
?>


    </div>
</body>

</html>