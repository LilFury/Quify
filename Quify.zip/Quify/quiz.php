<!-- quiz.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Page</title>
    <style>
  body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('QuifyBackground.jpg');
            background-position: center;
        }

        html, body {
            height: 100%;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        h1 {
            margin: 0;
        }

        .quiz-container {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            width: 50%;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin-top: 50px;
        }

        h2, h3 {
            color: #333;
            margin-top: 20px;
        }

        .question {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="radio"] {
            margin-right: 5px;
        }

        button {
            display: inline-block;
            padding: 10px 15px;
            background-color: #3498db;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        button:hover {
            background-color: #2980b9;
        }
        header ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logout-button {
            display: inline-block;
            padding: 8px 12px;
            background-color: #e74c3c;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        .logout-button:hover {
            background-color: #c0392b;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }

        /* Add this style to handle table */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
            color: #333;
        }


    </style>
</head>
<body>
    <header>
    <ul>
            <li><a href="userpage.php"><img src="quifylogos.png" width="80" height="40"></a></li>
            <li><a href="team.php">Team Gallery</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li class="logout-container">
                <a href="login.php" class="logout-button">Logout</a>
            </li>
        </ul>
    </header>

    <div class="quiz-container">
        <h2>Welcome to the Quiz!</h2>

        <?php
        // Establish a database connection (replace these with your actual database credentials)
        $host = 'localhost';
        $dbname = 'quify';
        $db_username = 'root';
        $db_password = '';

        try {
            $pdo = new PDO("mysql:host=$host;dbname=$dbname", $db_username, $db_password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error: " . $e->getMessage());
        }

        // Retrieve distinct questions and their associated answer options from the database
        $stmt = $pdo->prepare("SELECT q.*, GROUP_CONCAT(a.answer) as answers FROM questions q JOIN answers a ON q.qid = a.qid GROUP BY q.qid");
        $stmt->execute();
        $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Display distinct questions and their associated answer options
        foreach ($questions as $q) {
            echo '<div class="question">';
            echo '<label><strong>Question:</strong> ' . $q['question'] . '</label>';
            echo '<ul>';

            // Explode the concatenated answers into an array
            $answers = explode(',', $q['answers']);

            // Display each answer as an option
            foreach ($answers as $answer) {
                echo '<li><input type="radio" name="q' . $q['qid'] . '" value="' . $answer . '"> ' . $answer . '</li>';
            }

            echo '</ul>';
            echo '</div>';
        }
        ?>

        <button onclick="submitQuiz()">Submit Quiz</button>
    </div>
    <script>
     function submitQuiz() {
    var userAnswers = collectUserAnswers();

    // Check if at least one answer is selected
    if (userAnswers.length === 0) {
        alert("Please answer at least one question before submitting.");
        return;
    }

    // Redirect to the result.php page with the user's answers and questions
    window.location.href = 'result.php?userAnswers=' + JSON.stringify(userAnswers) + '&questions=' + encodeURIComponent(JSON.stringify(<?php echo json_encode($questions); ?>));
}

// Add your logic to collect user answers (customize this according to your implementation)
function collectUserAnswers() {
    var userAnswers = [];
    // Loop through each question and find the selected answer
    <?php
    foreach ($questions as $q) {
        echo 'var selectedAnswer = document.querySelector(\'input[name="q' . $q['qid'] . '"]:checked\');';
        echo 'if (selectedAnswer) {';
        echo 'userAnswers.push(selectedAnswer.value);';
        echo '}';
    }
    ?>
    return userAnswers;
}

    </script>
</body>
</html>