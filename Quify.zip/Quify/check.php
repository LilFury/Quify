<?php
// Replace these credentials with your actual database connection details
$host = 'localhost';
$dbname = 'quify';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

$email = $_GET['email'];
$username = $_GET['username'];

// Check if email already exists
$stmtEmail = $pdo->prepare("SELECT COUNT(*) FROM user WHERE email = ?");
$stmtEmail->execute([$email]);
$emailExists = $stmtEmail->fetchColumn() > 0;

// Check if username already exists
$stmtUsername = $pdo->prepare("SELECT COUNT(*) FROM user WHERE username = ?");
$stmtUsername->execute([$username]);
$usernameExists = $stmtUsername->fetchColumn() > 0;

// Return the result as JSON
echo json_encode(['emailExists' => $emailExists, 'usernameExists' => $usernameExists]);
?>
