<?php
ob_start(); // Start output buffering
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            display: flex;
            /* Use flexbox to align items */
            justify-content: space-between;
            /* Space between items */
            align-items: center;
            /* Center items vertically */
        }

        h1 {
            margin: 0;
            /* Remove default margin for h1 */
        }

        h2,
        h3 {
            color: #333;
            margin-top: 20px;
        }

        form {
            max-width: 500px;
            margin: 20px 0;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        a {
            display: block;
            margin-top: 20px;
            color: #3498db;
            text-decoration: none;
        }

        a:hover {
            background-color: #111;
        }

        .question-box {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        table {
            width: 100%;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        a.edit-button {
            display: inline-block;
            padding: 8px 12px;
            background-color: #3498db;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        a.edit-button:hover {
            background-color: #2980b9;
        }

        a.delete-button {
            display: inline-block;
            padding: 8px 12px;
            background-color: #e74c3c;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        a.delete-button:hover {
            background-color: #c0392b;
        }

        header ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logout-button {
            display: inline-block;
            padding: 8px 12px;
            background-color: #e74c3c;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            margin-right: auto;
        }

        .logout-button:hover {
            background-color: #c0392b;
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }
    </style>
</head>

<body>
    <header>
        <ul>
            <li><a href="adminpage.php"><img src="quifylogos.png" width="80" height="40"></a></li>
            <li><a href="team.php">Team Gallery</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li class="logout-container">
                <a href="login.php" class="logout-button">Logout</a>
            </li>
        </ul>
    </header>

    <?php
    // Establish a database connection (replace these with your actual database credentials)
    $host = 'localhost';
    $dbname = 'quify';
    $db_username = 'root';
    $db_password = '';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $db_username, $db_password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }

    // Handle question submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $question = $_POST['question'];  // Define $question
        $canswer = $_POST['canswer'];    // Define $canswer
        $options = $_POST['options'];    // Define $options
    
        // Insert question into the database
        $stmt = $pdo->prepare("INSERT INTO questions (question, canswer) VALUES (?, ?)");
        $stmt->execute([$question, $canswer]);
        $qid = $pdo->lastInsertId();

        // Insert options into the answers table
        foreach ($options as $option) {
            $stmt = $pdo->prepare("INSERT INTO answers (answer, qid) VALUES (?, ?)");
            $stmt->execute([$option, $qid]);
        }

        // Redirect to the same page with a success message
        header("Location: adminpage.php?success=1");
        exit();
    }

    // Retrieve created questions from the database
    $stmt = $pdo->prepare("SELECT q.*, a.answer FROM questions q JOIN answers a ON q.qid = a.qid");
    $stmt->execute();
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h3>Create a Question</h3>
    <form action="adminpage.php" method="post">
        <label for="question">Question:</label>
        <input type="text" name="question" required>

        <label for="canswer">Correct Answer:</label>
        <input type="text" name="canswer" required>

        <label for="options">Options:</label>
        <input type="text" name="options[]" required>
        <input type="text" name="options[]" required>
        <input type="text" name="options[]" required>
        <input type="text" name="options[]" required>

        <input type="submit" value="Create Question">
    </form>

    <h3>Created Questions</h3>
    <?php
    if (empty($questions)) {
        echo "<p>No questions found.</p>";
    } else {
        $previousQid = null;  // Keep track of the previous question ID
        foreach ($questions as $q) {
            // Check if it's a new question
            if ($q['qid'] !== $previousQid) {
                if ($previousQid !== null) {
                    echo "</tbody></table></div>";  // Close the previous table and question box
                }
                echo '<div class="question-box">';
                echo '<strong>Question:</strong> ' . $q['question'] . '<br>';
                echo '<strong>Correct Answer:</strong> ' . $q['canswer'] . '<br>';
                echo '<a href="edit.php?qid=' . $q['qid'] . '" class="edit-button">Edit</a>';
                echo '<a href="?delete=' . $q['qid'] . '" class="delete-button" onclick="return confirmDelete()">Delete</a>';
                echo '<table>';
                echo '<thead><tr><th>Options</th></tr></thead><tbody>';
            }

            // Display options
            echo '<tr><td>Option: ' . $q['answer'] . '</td></tr>';

            // Update the previous question ID
            $previousQid = $q['qid'];
        }
        echo "</tbody></table></div>";  // Close the last table and question box
    }
    ob_start(); // Start output buffering
    
    // Your existing PHP code here
    
    // Handle question deletion
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['delete'])) {
        $deleteQid = $_GET['delete'];

        try {
            // Start a transaction
            $pdo->beginTransaction();

            // Delete answers first
            $deleteOptionsStmt = $pdo->prepare("DELETE FROM answers WHERE qid = ?");
            $deleteOptionsStmt->execute([$deleteQid]);

            // Now delete the question
            $deleteQuestionStmt = $pdo->prepare("DELETE FROM questions WHERE qid = ?");
            $deleteQuestionStmt->execute([$deleteQid]);

            // Commit the transaction
            $pdo->commit();

            header("Location: adminpage.php?success=deleted");
            exit();
        } catch (PDOException $e) {
            // An error occurred, rollback the transaction
            $pdo->rollBack();
            die("Error: " . $e->getMessage());
        }
    }
    ob_end_flush();
    ?>

    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this question?");
        }
    </script>
</body>

</html>